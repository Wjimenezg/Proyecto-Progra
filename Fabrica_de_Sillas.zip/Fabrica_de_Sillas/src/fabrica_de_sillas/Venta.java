
package fabrica_de_sillas;

import java.util.*;


public class Venta {
    private int idVenta;
    private String tipoSilla;
    private String color;
    private double costoTotal;
    
    private Scanner scanner = new Scanner(System.in);
    //private Inventario inventario;
    private Proceso proceso;

    public Venta(int idVenta, String tipoSilla, String color, double costoTotal, Proceso proceso) {
    this.idVenta = idVenta;
    this.tipoSilla = tipoSilla;
    this.color = color;
    this.costoTotal = costoTotal;
    this.inventario = inventario;  // Esto debería ser "this.proceso = proceso;" en lugar de "this.inventario = inventario;".
    this.proceso = proceso;
        
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public String getTipoSilla() {
        return tipoSilla;
    }

    public void setTipoSilla(String tipoSilla) {
        this.tipoSilla = tipoSilla;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getCostoTotal() {
        return costoTotal;
    }

    public void setCostoTotal(double costoTotal) {
        this.costoTotal = costoTotal;
    }
    
    private Inventario inventario; // Asegúrate de tener una referencia al Inventario.

    public Venta(Inventario inventario) {
        this.inventario = inventario;
    }

    
        public boolean venderSilla(Proceso proceso, String tipoSilla, int cantidad) {
        int cantidadDisponible = inventario.getCantidadSilla(tipoSilla);

        if (cantidadDisponible >= cantidad) {
            // Hay suficientes sillas disponibles en el inventario.
            inventario.actualizarCantidadSilla(tipoSilla, -cantidad); // Resta la cantidad especificada del inventario.
            System.out.println("¡Venta realizada!");
            return true; // Devuelve true para indicar que la venta fue exitosa.
        } else {
            // No hay suficientes sillas disponibles en el inventario.
            System.out.println("No hay suficientes sillas en el inventario.");

            // Solicitar al usuario la cantidad de sillas a fabricar.
            System.out.println("¿Desea fabricar " + cantidad + " sillas " + tipoSilla + "? (Sí/No)");
            String respuesta = scanner.nextLine().trim().toLowerCase();
            if (respuesta.equals("si")) {
                proceso.fabricarSilla(tipoSilla, cantidad);
                System.out.println("¡Venta realizada!");
                return true; // Devuelve true para indicar que la venta fue exitosa después de fabricar sillas.
            } else {
                System.out.println("Venta cancelada.");
                return false; // Devuelve false para indicar que la venta fue cancelada.
            }
        }}}
    
       /* public boolean venderSilla(String tipoSilla, int cantidad) {
        int cantidadDisponible = inventario.getCantidadSilla(tipoSilla);
        
        if (cantidadDisponible >= cantidad) {
            // Hay suficientes sillas disponibles en el inventario.
            inventario.actualizarCantidadSilla(tipoSilla, -cantidad); // Resta la cantidad especificada del inventario.
            System.out.println("¡Venta realizada!");
            return true; // Devuelve true para indicar que la venta fue exitosa.
        } else {
            // No hay suficientes sillas disponibles en el inventario.
            System.out.println("No hay suficientes sillas en el inventario.");
            
            // Solicitar al usuario la cantidad de sillas a fabricar.
            System.out.println("¿Desea fabricar " + cantidad + " sillas " + tipoSilla + "? (Sí/No)");
            String respuesta = scanner.nextLine().trim().toLowerCase();
            if (respuesta.equals("si")) {
                proceso.fabricarSilla(tipoSilla, cantidad);
                System.out.println("¡Venta realizada!");
                return true; // Devuelve true para indicar que la venta fue exitosa después de fabricar sillas.
            } else {
                System.out.println("Venta cancelada.");
                return false; // Devuelve false para indicar que la venta fue cancelada.
            }
        }
    }/*
    
   /* public void venderSilla(String tipoSilla, int cantidad) {
    int cantidadDisponible = inventario.getCantidadSilla(tipoSilla);

    
    if (cantidadDisponible >= cantidad) {
        // Hay suficientes sillas disponibles en el inventario.
        inventario.actualizarCantidadSilla(tipoSilla, -cantidad); // Resta la cantidad especificada del inventario.
        System.out.println("¡Venta realizada!");
    } else {
        // No hay suficientes sillas disponibles en el inventario.
        System.out.println("No hay suficientes sillas en el inventario.");
        
        // Solicitar al usuario la cantidad de sillas a fabricar.
        System.out.println("¿Desea fabricar " + cantidad + " sillas " + tipoSilla + "? (Sí/No)");
        String respuesta = scanner.nextLine().trim().toLowerCase();
        if (respuesta.equals("si")) {
            proceso.fabricarSilla(tipoSilla, cantidad);
            System.out.println("¡Venta realizada!");
        } else {
            System.out.println("Venta cancelada.");
        }
    }
}*/
    /*public boolean venderSilla(String tipoSilla, int cantidad) {
    int cantidadDisponible = inventario.getCantidadSilla(tipoSilla);
    
    if (cantidadDisponible >= cantidad) {
        // Hay suficientes sillas disponibles en el inventario.
        inventario.actualizarCantidadSilla(tipoSilla, -cantidad); // Resta la cantidad especificada del inventario.
        return true; // Venta exitosa.
    } else {
        // No hay suficientes sillas disponibles en el inventario.
        return false; // Venta fallida.
    }
}*/
    
    

