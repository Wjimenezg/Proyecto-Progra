
package fabrica_de_sillas;

import java.util.*;
public class Producto {
    private Map<String, Double> precios;
    private Map<String, String> detalles;

    public Producto() {
        precios = new HashMap<>();
        detalles = new HashMap<>();

        // Agrega precios y detalles para cada tipo de silla
        precios.put("Gamer", 100.00);
        detalles.put("Gamer", "Una silla Gamer cómoda y ergonómica.");
        
        precios.put("Comedor", 150.00);
        detalles.put("Comedor", "Una silla de comedor elegante y resistente.");
        
        precios.put("Patio", 80.00);
        detalles.put("Patio", "Una silla de patio resistente a la intemperie.");
        
        precios.put("Oficina", 120.00);
        detalles.put("Oficina", "Una silla de oficina ergonómica y funcional.");
        
        precios.put("Sencilla", 70.00);
        detalles.put("Sencilla", "Una silla sencilla y versátil.");
    }
    


    public double obtenerPrecio(String tipoSilla) {
        return precios.getOrDefault(tipoSilla, 0.0);
    }

    public String obtenerDetallesSilla(String tipoSilla) {
        return detalles.getOrDefault(tipoSilla, "No se encontraron detalles para esta silla.");
    }
    
    public Map<String, Double> getPrecios() {
        return precios;
}
}

