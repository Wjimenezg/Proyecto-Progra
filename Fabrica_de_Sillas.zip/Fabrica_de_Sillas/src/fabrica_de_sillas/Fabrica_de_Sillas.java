package fabrica_de_sillas;

import java.util.*;
public class Fabrica_de_Sillas {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Inventario inventario = new Inventario();
        Producto producto = new Producto();
        Proceso proceso = new Proceso(inventario, producto);
        Venta venta = new Venta(inventario);

        proceso.insertar(); // Agregar materiales al inventario al inicio del programa

        while (true) {
            System.out.println("--------------------------------------");
            System.out.println("| Bienvenido a la Fábrica de Sillas   |");
            System.out.println("| Elija una opción:                   |");
            System.out.println("| 1. Ver Producto                     |");
            System.out.println("| 2. Ver Inventario                   |");
            System.out.println("| 3. Vender Silla                     |");
            System.out.println("| 4. Salir                            |");
            System.out.println("--------------------------------------");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la nueva línea

            switch (opcion) {
                case 1:
                    System.out.println("Detalles de los Productos Disponibles:");
                    for (String tipoSilla : producto.getPrecios().keySet()) {
                        String detalles = producto.obtenerDetallesSilla(tipoSilla);
                        double precio = producto.obtenerPrecio(tipoSilla);

                        System.out.println("Tipo de Silla: " + tipoSilla);
                        System.out.println("Precio: $" + precio);
                        System.out.println("Detalles: " + detalles);
                        System.out.println(); // Separador entre productos
                    }
                    break;
                case 2:
                    System.out.println("Inventario de Sillas:");
                    System.out.println("Tipo de silla - Cantidad");

                    // Recorre los tipos de sillas disponibles e imprime su cantidad en el inventario.
                    for (String tipoSilla : inventario.tiposSillas.keySet()) {
                        int cantidad = inventario.getCantidadSilla(tipoSilla);
                        System.out.println(tipoSilla + " - " + cantidad);
                    }

                    System.out.println("Inventario de Materiales:");
                    System.out.println("Material - Cantidad");

                    // Recorre los materiales disponibles e imprime su cantidad en el inventario.
                    for (String material : inventario.materiales.keySet()) {
                        int cantidad = inventario.getCantidadMaterial(material);
                        System.out.println(material + " - " + cantidad);
                    }
                    break;
                case 3:
                    System.out.println("Venta de Silla:");
                    System.out.println("Elija el tipo de silla a vender:");
                    System.out.println("1. Gamer");
                    System.out.println("2. Comedor");
                    System.out.println("3. Patio");
                    System.out.println("4. Oficina");
                    System.out.println("5. Sencilla");
                    int opcionSilla = scanner.nextInt();
                    scanner.nextLine(); // Consumir la nueva línea
                    String tipoSilla = "";

                    switch (opcionSilla) {
                        case 1:
                            tipoSilla = "Gamer";
                            break;
                        case 2:
                            tipoSilla = "Comedor";
                            break;
                        case 3:
                            tipoSilla = "Patio";
                            break;
                        case 4:
                            tipoSilla = "Oficina";
                            break;
                        case 5:
                            tipoSilla = "Sencilla";
                            break;
                        default:
                            System.out.println("Opción no válida. Por favor, elija nuevamente.");
                            continue;
                    }

                    System.out.println("Ingrese la cantidad de sillas a vender:");
                    int cantidad = scanner.nextInt();
                    scanner.nextLine(); // Consumir la nueva línea

                    boolean ventaExitosa = venta.venderSilla(proceso, tipoSilla, cantidad);

                    if (ventaExitosa) {
                        System.out.println("¡Venta realizada!");
                    } else {
                        System.out.println("No hay suficientes sillas en el inventario.");

                        // Verificar si se deben fabricar sillas
                        System.out.println("¿Desea fabricar " + cantidad + " sillas " + tipoSilla + "? (Sí/No)");
                        String respuesta = scanner.nextLine().trim().toLowerCase();
                        if (respuesta.equals("si")) {
                            boolean fabricacionExitosa = proceso.fabricarSilla(tipoSilla, cantidad);

                            if (fabricacionExitosa) {
                                System.out.println("¡Venta realizada!");
                            } else {
                                System.out.println("No se pudo realizar la venta.");
                            }
                        } else {
                            System.out.println("Venta cancelada.");
                        }
                    }
                    break;
                case 4:
                    System.out.println("¡Gracias por visitar la Fábrica de Sillas!");
                    return;
                default:
                    System.out.println("Opción no válida. Por favor, elija nuevamente.");
            }
        }
    
    }
    }
